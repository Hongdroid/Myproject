package main_page;

public class ex_time {

	public static void main(String[] args) {
		for(int i = 0; i < 5; i++) {
			
			
			try {
				System.out.println(i);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
