package model;

public class InsertChallenge {
	
	   private String routine , habit;
	   private int habit_time;
	   public InsertChallenge(String day, String hob, int time) {
	      this.routine = day;
	      this.habit = hob;
	      this.habit_time = time;
	   }
	   public String getroutine () {
	      return routine ;
	   }
	   public void setRoutine_id(String day) {
	      this.routine  = day;
	   }
	   public String getHabit() {
	      return habit;
	   }
	   public void setHabit(String hob) {
	      this.habit = hob;
	   }
	   public int getHabit_time() {
	      return habit_time;
	   }
	   public void setHabit_time(int time) {
	      this.habit_time = time;
	   }

	

}
