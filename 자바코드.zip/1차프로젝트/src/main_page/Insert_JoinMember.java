package main_page;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;
import model.InsertVo;

public class Insert_JoinMember {

	private JFrame frame;
	private JTextField text_id;
	private JTextField text_pw;
	private JTextField text_name;
	private JTextField text_age;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Insert_JoinMember window = new Insert_JoinMember();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Insert_JoinMember() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("HY����L", Font.BOLD, 30));
		frame.getContentPane().setBackground(new Color(250, 240, 230));
		frame.setBounds(100, 100, 1078, 662);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		text_id = new JTextField();
		text_id.setBounds(423, 207, 228, 40);
		frame.getContentPane().add(text_id);
		text_id.setColumns(10);

		text_pw = new JTextField();
		text_pw.setColumns(10);
		text_pw.setBounds(423, 270, 228, 40);
		frame.getContentPane().add(text_pw);

		text_name = new JTextField();
		text_name.setColumns(10);
		text_name.setBounds(423, 334, 228, 40);
		frame.getContentPane().add(text_name);

		text_age = new JTextField();
		text_age.setColumns(10);
		text_age.setBounds(423, 397, 228, 40);
		frame.getContentPane().add(text_age);

		JButton btn_insert = new JButton("\uAC00\uC785\uC644\uB8CC");
		btn_insert.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				String id = text_id.getText();
				String pw = text_pw.getText();
				String name = text_name.getText();
				int age = Integer.parseInt(text_age.getText());
				// System.out.println(id+pw+name+age);

				// InsertVO vo = new InsertVO(id, pw, name, age);

				DAO dao = new DAO();
				int result = dao.insert(new InsertVo(id, pw, name, age));

				if (result > 0) {

					// �˾�â ����!
					JOptionPane.showMessageDialog(null, "ȸ������ ����!", "ȸ������ ����â", JOptionPane.INFORMATION_MESSAGE);
					// showMessageDialog(�θ�������Ʈ, ����� �޽���, ����, ������)

				} else {
					JOptionPane.showMessageDialog(null, "ȸ������ ����!", "ȸ������ ����â", JOptionPane.ERROR_MESSAGE);
				}

				Login.main(null);
				frame.dispose();
			}
		});
		btn_insert.setBackground(new Color(255, 255, 255));
		btn_insert.setForeground(new Color(0, 0, 0));
		btn_insert.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_insert.setBounds(423, 482, 228, 41);
		frame.getContentPane().add(btn_insert);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\smhrd\\Desktop\\asdasdasdasdazzz.jpg"));
		lblNewLabel_1.setBounds(0, 0, 1062, 623);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\signup.jpg"));
		lblNewLabel.setBounds(0, 0, 1062, 623);
		frame.getContentPane().add(lblNewLabel);
	}

}
