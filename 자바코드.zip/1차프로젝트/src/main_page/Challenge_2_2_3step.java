package main_page;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import DAO.DAO;
import GUI_.MyDefaultTableCellRenderer;
import model.InsertCategory;
import model.InsertChallenge;
import model.InsertVo;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Challenge_2_2_3step implements Runnable {

   private JFrame frame;
   private JTable table;
   private JLabel lbl_timer;
   Thread thread = new Thread(this);
   int time;
   JPanel panel;
   protected static final TableCellRenderer dtcr1 = null;
   private JTextField text_routine;
   private JTextField text_habit;
   private JTextField text_habit_time;
   private JTextField text_chal;
   private JTextField text_check;
   private JButton btnNewButton_1;
   private JButton btnNewButton;
   private JLabel lblNewLabel;
   private JLabel lblNewLabel_1;
   private JLabel lblNewLabel_2;
   private JLabel lblNewLabel_3;
   private JLabel lblNewLabel_4;
   private JLabel lblNewLabel_5;
   private JLabel lblNewLabel_6;
   private JLabel lblNewLabel_7;
   private JLabel lblNewLabel_8;
   private JLabel lblNewLabel_9;
   private JTextField text_achieve;
   private JButton btnNewButton_5;
   private JButton btnNewButton_6;
   private JLabel lblNewLabel_10;
   private JLabel lblNewLabel_11;
   private JLabel lblNewLabel_12;
   private JLabel lblNewLabel_13;
   private JLabel lblNewLabel_14;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
            	Challenge_2_2_3step window = new Challenge_2_2_3step();
               window.frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the application.
    */
   public Challenge_2_2_3step() {
      initialize();
   }

   /**
    * Initialize the contents of the frame.
    */
   private void initialize() {

      frame = new JFrame();
      frame.setBounds(100, 100, 1078, 662);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().setLayout(null);

      panel = new JPanel();
      panel.setBounds(0, 0, 1062, 623);
      frame.getContentPane().add(panel);
      panel.setLayout(null);

      
      
      text_routine = new JTextField();
      text_routine.setFont(new Font("���� ����", Font.BOLD, 14));
      text_routine.setBounds(793, 150, 129, 30);
      panel.add(text_routine);
      text_routine.setColumns(10);

      text_habit = new JTextField();
      text_habit.setFont(new Font("���� ����", Font.BOLD, 14));
      text_habit.setColumns(10);
      text_habit.setBounds(793, 200, 129, 30);
      panel.add(text_habit);

      text_habit_time = new JTextField();
      text_habit_time.setFont(new Font("���� ����", Font.BOLD, 14));
      text_habit_time.setColumns(10);
      text_habit_time.setBounds(793, 250, 129, 30);
      panel.add(text_habit_time);

      text_check = new JTextField();
      text_check.setFont(new Font("���� ����", Font.BOLD, 14));
      text_check.setColumns(10);
      text_check.setBounds(793, 400, 129, 30);
      panel.add(text_check);

      JScrollPane scrollPane = new JScrollPane();
      scrollPane.setBounds(10, 67, 656, 391);
      panel.add(scrollPane);

      table = new JTable();
      scrollPane.setViewportView(table);
      table.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            int selectedRowIndex = table.getSelectedRow();

            text_routine.setText((String) model.getValueAt(selectedRowIndex, 0));
            text_habit.setText((String) model.getValueAt(selectedRowIndex, 1));
            text_habit_time.setText((int) model.getValueAt(selectedRowIndex, 2) + "");
            text_chal.setText((int) model.getValueAt(selectedRowIndex, 3) + "");
            text_achieve.setText((String) model.getValueAt(selectedRowIndex, 4));
            text_check.setText((boolean) model.getValueAt(selectedRowIndex, 5) + "");

         }
      });

      DAO dao = new DAO();
      ArrayList<InsertCategory> list = dao.selectCategory(Login.cur_id);

      String[] column = { "�Ϸ����", "�� ��", "��", "��ȣ","�޼� ����","üũ �ϱ�" };

      Object[][] data = new Object[list.size()][column.length];

      for (int i = 0; i < list.size(); i++) {
         data[i][0] = list.get(i).getRoutine();
         data[i][1] = list.get(i).getHabit();
         data[i][2] = list.get(i).getHabit_time();
         data[i][3] = list.get(i).getChal();
         data[i][4] = list.get(i).getAchieve();
         
      }
      table.setModel(new DefaultTableModel(data, column));
      table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      JCheckBox CheckBox = new JCheckBox();
      table.getColumn("üũ �ϱ�").setCellRenderer(dtcr1);
      table.getColumn("üũ �ϱ�").setCellEditor(new DefaultCellEditor(CheckBox));
      DefaultTableCellRenderer render = new MyDefaultTableCellRenderer();
      table.getColumn("üũ �ϱ�").setCellRenderer(render);

      table.setModel(new DefaultTableModel(data, column));
      table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      JButton btnNewButton_2 = new JButton("\uD0C0\uC774\uBA38");
      btnNewButton_2.addMouseListener(new MouseAdapter() {

         @Override
         public void mouseClicked(MouseEvent arg0) {
//            Timer timer = new Timer();
//            TimerTask task = new TimerTask() {
//               
//               @Override
//               public void run() {
//                  
//                  // TODO Auto-generated method stub
//                  
//               }
//            };
//            timer.schedule(task, null);
            time = (int) table.getModel().getValueAt(table.getSelectedRow(), 2);
            int sec = 0;
            String time2 = "0" + time + ":0" + sec;

            lbl_timer.setText(time2);
            thread.start();

         }
      });
      btnNewButton_2.setBounds(10, 468, 188, 77);
      panel.add(btnNewButton_2);

      lbl_timer = new JLabel("");
      lbl_timer.setBounds(210, 468, 289, 145);
      lbl_timer.setFont(new Font("���� ����", Font.BOLD, 50));
      lbl_timer.setHorizontalAlignment(SwingConstants.CENTER);
      panel.add(lbl_timer);

      JButton btnNewButton_4 = new JButton("\uB2EC\uC131\uC5EC\uBD80\uCCB4\uD06C");
      btnNewButton_4.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            DAO dao = new DAO();
            ArrayList<InsertCategory> list = dao.selectCategory(Login.cur_id);

            String[] column = { "�Ϸ����", "�� ��", "��", "��ȣ","�޼� ����","üũ �ϱ�" };

            Object[][] data = new Object[list.size()][column.length];

            for (int i = 0; i < list.size(); i++) {
            	 data[i][0] = list.get(i).getRoutine();
                 data[i][1] = list.get(i).getHabit();
                 data[i][2] = list.get(i).getHabit_time();
                 data[i][3] = list.get(i).getChal();
                 data[i][4] = list.get(i).getAchieve();
            }
            table.setModel(new DefaultTableModel(data, column));
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            JCheckBox CheckBox = new JCheckBox();
            table.getColumn("üũ �ϱ�").setCellRenderer(dtcr1);
            table.getColumn("üũ �ϱ�").setCellEditor(new DefaultCellEditor(CheckBox));
            DefaultTableCellRenderer render = new MyDefaultTableCellRenderer();
            table.getColumn("üũ �ϱ�").setCellRenderer(render);
         }
      });
      btnNewButton_4.setBounds(678, 67, 114, 65);
      panel.add(btnNewButton_4);
      
      text_chal = new JTextField();
      text_chal.setFont(new Font("���� ����", Font.BOLD, 14));
      text_chal.setColumns(10);
      text_chal.setBounds(793, 300, 129, 30);
      panel.add(text_chal);
      
      text_achieve = new JTextField();
      text_achieve.setFont(new Font("���� ����", Font.BOLD, 14));
      text_achieve.setColumns(10);
      text_achieve.setBounds(793, 350, 129, 30);
      panel.add(text_achieve);

      JLabel lblNewLabel = new JLabel("\uC791\uC2EC\uBCF4\uB984!!!!");
      lblNewLabel.setFont(new Font("����", Font.PLAIN, 30));
      lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel.setBounds(10, 0, 444, 79);
      panel.add(lblNewLabel);
      
      lblNewLabel_4 = new JLabel("\uD558\uB8E8\uB2E8\uC704");
      lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel_4.setBounds(678, 150, 92, 28);
      panel.add(lblNewLabel_4);
      
      lblNewLabel_5 = new JLabel("\uD560 \uC77C");
      lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel_5.setBounds(678, 200, 92, 28);
      panel.add(lblNewLabel_5);
      
      lblNewLabel_6 = new JLabel("\uBD84");
      lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel_6.setBounds(678, 250, 92, 28);
      panel.add(lblNewLabel_6);
      
      lblNewLabel_7 = new JLabel("\uCCB4\uD06C\uD558\uAE30!");
      lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel_7.setBounds(678, 400, 92, 28);
      panel.add(lblNewLabel_7);
      
      lblNewLabel_8 = new JLabel("\uBC88\uD638");
      lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel_8.setBounds(678, 300, 92, 28);
      panel.add(lblNewLabel_8);
      
      lblNewLabel_9 = new JLabel("\uB2EC\uC131\uC5EC\uBD80");
      lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
      lblNewLabel_9.setBounds(678, 350, 92, 28);
      panel.add(lblNewLabel_9);
      
      
      btnNewButton_5 = new JButton("\uC5EC\uBD80 \uC785\uB825!");
      btnNewButton_5.addMouseListener(new MouseAdapter() {
      	@Override
      	public void mouseClicked(MouseEvent e) {
      		
			int chal = Integer.parseInt(text_chal.getText());
			String achieve = text_achieve.getText();
			String check2 =  text_check.getText();

			int result = dao.Chal_fixmyhabit(new InsertCategory(achieve, chal, check2));
			if (result > 0) {
				JOptionPane.showMessageDialog(null, "�޼����� üũ �Ϸ�!", "����â", JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "�޼����� üũ ����!", "����â", JOptionPane.ERROR_MESSAGE);
			}

		}
      });
      btnNewButton_5.setBounds(934, 403, 116, 23);
      panel.add(btnNewButton_5);
      
      btnNewButton_6 = new JButton("\uC131\uACF5 \uC870\uD68C\uD558\uAE30!");
      btnNewButton_6.addMouseListener(new MouseAdapter() {
      	@Override
      	public void mouseClicked(MouseEvent e) {

			////
			int allCount = dao.Chal_allAchieve();
			int yCount = dao.Chal_yAchieve();

			int total = (100 / allCount) * yCount;

			JOptionPane.showMessageDialog(null, "���� ����������� �α��α��α�..", "â", JOptionPane.INFORMATION_MESSAGE);
			if (total > 90) {
				for (int i = 0; i < 1; i++) {
					try {
						System.out.println(i);
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}

				JOptionPane.showMessageDialog(null, "��������!. �޼���:" + total, "����â", JOptionPane.INFORMATION_MESSAGE);
				MyPage_Diary_copy.Challenge_num3 ++;   // ��� �ڵ� �ο��ϱ�
				if(MyPage_Diary_copy.Challenge_num3 > 15) {
					JOptionPane.showMessageDialog(null, "3�ܰ� ���� ����!", "����â", JOptionPane.INFORMATION_MESSAGE);
				}
				int result = dao.Chal_delete();
				System.out.println("������ �� : " + result);
				int creation = dao.Chal_creation();
				System.out.println("�� �� ��ȣ �����, " + creation);
				MyPage_Diary_copy.main(null);
				frame.dispose();
			} else {
				JOptionPane.showMessageDialog(null, "��������. �޼���:" + total, "����â", JOptionPane.ERROR_MESSAGE);
			
				int result = dao.Chal_delete();
				System.out.println("������ �� : " + result);
				int creation = dao.Chal_creation();
				System.out.println("�� �� ��ȣ �����, " + creation);
				MyPage_Diary_copy.main(null);
				frame.dispose();

			}
		}
      });
      btnNewButton_6.setFont(new Font("����", Font.PLAIN, 18));
      btnNewButton_6.setBounds(793, 466, 257, 79);
      panel.add(btnNewButton_6);
      
      lblNewLabel_10 = new JLabel("\uB2EC\uC131\uC5EC\uBD80 true\uAC00 90%");
      lblNewLabel_10.setBounds(668, 469, 177, 23);
      panel.add(lblNewLabel_10);
      
      lblNewLabel_11 = new JLabel("\uC774\uC0C1\uC774\uBA74 \uC131\uACF5\uC870\uD68C!");
      lblNewLabel_11.setBounds(668, 488, 177, 23);
      panel.add(lblNewLabel_11);
      
      lblNewLabel_12 = new JLabel("\uC6D0\uD558\uB294 \uD560 \uC77C\uC744 \uD074\uB9AD\uD558\uACE0");
      lblNewLabel_12.setBounds(10, 555, 187, 30);
      panel.add(lblNewLabel_12);
      
      lblNewLabel_13 = new JLabel("\uD0C0\uC774\uBA38\uB97C \uD074\uB9AD\uD558\uC138\uC694!");
      lblNewLabel_13.setBounds(10, 583, 187, 30);
      panel.add(lblNewLabel_13);
      
      lblNewLabel_14 = new JLabel("\uB2EC\uC131\uC5EC\uBD80 \uBA3C\uC800\uCCB4\uD06C!");
      lblNewLabel_14.setFont(new Font("����", Font.PLAIN, 15));
      lblNewLabel_14.setBounds(678, 10, 210, 47);
      panel.add(lblNewLabel_14);

   }

   @Override
   public void run() {
      int cnt = 60;
      String time2 = "";
      time -= 1;
      while (true) {
         try {
            Thread.sleep(1000);
            cnt--;
            if (cnt < 0) {
               cnt = 60;
               time -= 1;
            }
            if (cnt < 10) {
               time2 = "0" + time + ":0" + cnt;
            } else {
               time2 = "0" + time + ":" + cnt;

            }
            lbl_timer.setText(time2);
            if (time == 0 && cnt == 0) {
               JOptionPane.showMessageDialog(null, "���� ����!");
               break;
            }
         } catch (InterruptedException e) {
            e.printStackTrace();
         }
      }

   }
}