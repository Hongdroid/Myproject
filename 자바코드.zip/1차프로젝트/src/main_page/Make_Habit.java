package main_page;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import com.toedter.calendar.JDateChooser;

import DAO.DAO;
import GUI_.MyDefaultTableCellRenderer;
import model.DiaryVO;
import model.InsertDiary;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Make_Habit {

	private JFrame frame;
	private JTextField text_habit_goal;
	ButtonGroup group = new ButtonGroup();
	private DAO dao;
	private JTable table;
	private ArrayList<InsertDiary> list, returnList;
	protected static final TableCellRenderer dtcr1 = null;
	private JTable table_1;
	private DefaultTableModel model;
	public static String cur_id;
	private JTextField text_achieve;
	private JTextField text_event_id;
	public static int total;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Make_Habit window = new Make_Habit();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Make_Habit() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1078, 662);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 0, 1062, 623);
		frame.getContentPane().add(tabbedPane);

		JPanel panel = new JPanel();
		tabbedPane.addTab("�Է¶�", null, panel, null);
		panel.setLayout(null);

		JDateChooser date_start = new JDateChooser();
		date_start.setBounds(285, 108, 129, 25);
		panel.add(date_start);

		JDateChooser date_last = new JDateChooser();
		date_last.setBounds(285, 165, 129, 25);
		panel.add(date_last);

		text_habit_goal = new JTextField();
		text_habit_goal.setBounds(57, 285, 290, 25);
		panel.add(text_habit_goal);
		text_habit_goal.setColumns(10);

		JRadioButton radioButton_even1 = new JRadioButton("\uC6B4\uB3D9");
		radioButton_even1.setBounds(57, 60, 65, 32);
		panel.add(radioButton_even1);
		group.add(radioButton_even1);

		JRadioButton radioButton_even2 = new JRadioButton("\uACF5\uBD80");
		radioButton_even2.setBounds(143, 60, 65, 32);
		panel.add(radioButton_even2);
		group.add(radioButton_even2);

		JRadioButton radioButton_even3 = new JRadioButton("\uCDE8\uBBF8");
		radioButton_even3.setBounds(222, 60, 65, 32);
		panel.add(radioButton_even3);
		group.add(radioButton_even3);

		JRadioButton radioButton_even4 = new JRadioButton("\uC0DD\uD65C\uC2B5\uAD00");
		radioButton_even4.setBounds(304, 60, 89, 32);
		panel.add(radioButton_even4);
		group.add(radioButton_even4);

		JRadioButton radioButton_even5 = new JRadioButton("\uAE30\uD0C0");
		radioButton_even5.setBounds(420, 60, 65, 32);
		panel.add(radioButton_even5);
		group.add(radioButton_even5);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(508, 24, 522, 392);
		panel.add(scrollPane);

		JButton btn_insert_ = new JButton("\uC785\uB825");
		btn_insert_.setBounds(386, 285, 72, 54);
		panel.add(btn_insert_);

		JButton btn_close = new JButton("\uB2EB\uAE30");
		btn_close.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
			}
		});
		btn_close.setBounds(933, 468, 97, 75);
		panel.add(btn_close);

		JButton btn_delete = new JButton("\uC0AD\uC81C");
		btn_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_delete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				int index = table_1.getSelectedRow();
				model.removeRow(index);
				table_1.setModel(model);

			}
		});
		btn_delete.setBounds(651, 468, 97, 75);
		panel.add(btn_delete);

		table_1 = new JTable();
		table_1.setFont(new Font("HY�߰���", Font.PLAIN, 12));
		scrollPane.setViewportView(table_1);

		JButton btn_allselect = new JButton("\uC804\uCCB4\uBCF4\uAE30");
		btn_allselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_allselect.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {

				//// ��ü �Է�
				dao = new DAO();

				// test start

				int allCount = dao.allAchieve();
				int yCount = dao.yAchieve();

				System.out.println("�޼��� : " + 1.0 * yCount / allCount * 100);
				

				// test end

				list = dao.allSelect_diary(Login.cur_id);
//				ArrayList<InsertDiary> list = dao.allSelect_diary(Login.cur_id);

				if (list.size() != 0) {

					String[] column = { "�з�", "��ǥ ����", "���� ��¥", "�Ϸ� ��¥", "�޼� ����", "������ȣ" };
					Object[][] data = new Object[list.size()][column.length];

					for (int i = 0; i < list.size(); i++) {
						data[i][0] = list.get(i).getEvent();
						data[i][1] = list.get(i).getGoal();
						data[i][2] = list.get(i).getStart_date();
						data[i][3] = list.get(i).getFinal_date();
						data[i][4] = list.get(i).getAchieve();
						data[i][5] = list.get(i).getEvent_id();
						
					}
					model = new DefaultTableModel(data, column);
					table_1.setModel(model);
					total = (int) (1.0 * yCount / allCount * 100);
//					table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//					JCheckBox CheckBox = new JCheckBox();
//					table_1.getColumn("�޼� ����").setCellRenderer(dtcr1);
//					table_1.getColumn("�޼� ����").setCellEditor(new DefaultCellEditor(CheckBox));
//					DefaultTableCellRenderer render = new MyDefaultTableCellRenderer();
//					System.out.println(table_1.getColumn("�޼� ����"));
//					table_1.getColumn("�޼� ����").setCellRenderer(render);
//					table.setModel(new DefaultTableModel(data, column));
				} else {
					JOptionPane.showMessageDialog(null, "���� ������ �����ϴ�.", "������ �Է����ּ���", JOptionPane.ERROR_MESSAGE);
				}
			}

		});
		btn_allselect.setBounds(508, 468, 97, 75);
		panel.add(btn_allselect);

		JLabel lbl_achieve = new JLabel("\uB2EC\uC131\uC5EC\uBD80 (Y/N)");
		lbl_achieve.setFont(new Font("����", Font.BOLD, 17));
		lbl_achieve.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_achieve.setBounds(26, 485, 143, 38);
		panel.add(lbl_achieve);

		JButton btn_save = new JButton("\uC800\uC7A5");
		btn_save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_save.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				returnList = new ArrayList<InsertDiary>();

				for (int i = 0; i < model.getRowCount(); i++) {

					String event = (String) model.getValueAt(i, 0);
					String goal = (String) model.getValueAt(i, 1);
					Date start_date = (Date) model.getValueAt(i, 2);
					Date final_date = (Date) model.getValueAt(i, 3);
					String achieve = (String) model.getValueAt(i, 4);
					int event_id = (int) model.getValueAt(i, 5);

					InsertDiary diaryData = new InsertDiary(event, goal, start_date, final_date, achieve, event_id);
					returnList.add(diaryData);
				}

				dao.InsertUpdate(returnList);

			}
		});
		btn_save.setBounds(801, 468, 97, 75);
		panel.add(btn_save);
		
		text_achieve = new JTextField();
		text_achieve.setBounds(170, 495, 116, 21);
		panel.add(text_achieve);
		text_achieve.setColumns(10);
		
		JLabel lbl_event_id = new JLabel("\uC2B5\uAD00\uBC88\uD638");
		lbl_event_id.setFont(new Font("����", Font.BOLD, 17));
		lbl_event_id.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_event_id.setBounds(33, 425, 125, 45);
		panel.add(lbl_event_id);
		
		text_event_id = new JTextField();
		text_event_id.setColumns(10);
		text_event_id.setBounds(170, 434, 116, 21);
		panel.add(text_event_id);
		
		JButton btn_insert__1 = new JButton("\uB2EC\uC131\uC5EC\uBD80\uCCB4\uD06C");
		btn_insert__1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				/////
				int event_id = Integer.parseInt(text_event_id.getText());
				String achieve = text_achieve.getText(); 
				
				
			//	InsertDiary diary = new InsertDiary(achieve, event_id);
				int result = dao.fixmyhabit(new InsertDiary(achieve, event_id));
				
				if(result > 0) {
					JOptionPane.showMessageDialog(null, "�޼����� üũ �Ϸ�!", "����â", JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null, "�޼����� üũ ����!", "����â", JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
		});
		btn_insert__1.setBounds(337, 484, 123, 38);
		panel.add(btn_insert__1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\\uC0AC\uC9C4\\habitmaker.jpg"));
		lblNewLabel.setBounds(0, 0, 1057, 594);
		panel.add(lblNewLabel);

		btn_insert_.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

//	    		  if(JRadioButton != null) {
//  			  String event = radioButton_even1.getText();
//  		  }
				String event = "";
				for (Enumeration<AbstractButton> em = group.getElements(); em.hasMoreElements();) {

					AbstractButton btn = em.nextElement();
					if (btn.isSelected()) {
						event = btn.getText();
					}

				}
				String habit = text_habit_goal.getText();
				Date start_date = date_start.getDate();
				Date last_date = date_last.getDate();

				dao = new DAO();

				int result = dao.insertGoal(new InsertDiary(event, habit, start_date, last_date));

				if (result > 0) {
					JOptionPane.showMessageDialog(null, "���� ����� ����!", "����â", JOptionPane.INFORMATION_MESSAGE);
				}

				// util
				// sql

			}
		});
	}
}