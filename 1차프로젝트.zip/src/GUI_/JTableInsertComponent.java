package GUI_;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import DAO.DAO;
import main_page.MyPage_Diary_copy;
import model.InsertVo;

public class JTableInsertComponent {
   DefaultTableModel model;
   JTable table;
   Object[][] data = { { "����", "����;", "����" }, { "����", "����;", "����" } };
   String[] colName = { "�ð�", "�� ��", "��" };

   public void showAllData() {
      DAO dao = new DAO();
      model = new DefaultTableModel(data, colName);
   }

   public void display() {
      Container c = getContentPane();
      showAllData();
      table = new JTable(model);
      table.getColumnModel().getColumn(7).setPreferredWidth(150);
      table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      JScrollPane scroll = new JScrollPane(table);
      DefaultTableCellRenderer renderer = new MyDefaultTableCellRenderer();
      table.getColumn("��").setCellRenderer(renderer);
      c.add(scroll, BorderLayout.CENTER);
   }

   private Container getContentPane() {
      // TODO Auto-generated method stub
      return null;
   }


   public static void main(String[] args) {
      JTableInsertComponent obj = new JTableInsertComponent();
      
   }

}