package main_page;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Challenge_choice {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Challenge_choice window = new Challenge_choice();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Challenge_choice() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 484, 361);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uCC4C\uB9B0\uC9C0 \uC120\uD0DD\uC744\uD558\uC138\uC694! \uCC98\uC74C\uC5D0\uB294 1\uB2E8\uACC4 \uC2DC\uC791");
		lblNewLabel.setBounds(23, 133, 377, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uB2E8\uACC4\uBCC4\uB85C \uD074\uB9AC\uC5B4 \uD574\uC57C \uB3C4\uC804 \uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4!");
		lblNewLabel_1.setBounds(23, 147, 377, 42);
		panel.add(lblNewLabel_1);
		
		JButton btn_3Chal = new JButton("1\uB2E8\uACC4.\uC791\uC2EC\uC0BC\uC77C!");
		btn_3Chal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_3Chal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Challenge_2_2.main(null);
				frame.dispose();
			}
		});
		btn_3Chal.setBounds(23, 199, 200, 40);
		panel.add(btn_3Chal);
		
		JButton btn_7Chal = new JButton("2\uB2E8\uACC4.\uC791\uC2EC\uC77C\uC8FC\uC77C~");
		btn_7Chal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_7Chal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(MyPage_Diary_copy.Challenge_num >= 3) {
					Challenge_2_2_2step.main(null);
				}else {
					JOptionPane.showMessageDialog(null, "1�ܰ� �����ϰ� ������ ^^", "���� ���� �ȵ�!", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btn_7Chal.setBounds(23, 249, 200, 40);
		panel.add(btn_7Chal);
		
		JLabel lblNewLabel_2 = new JLabel("\uC5B4\uC81C\uC640 \uB611\uAC19\uC774 \uC0B4\uBA74\uC11C \uB2E4\uB978 \uBBF8\uB798\uB97C \uAE30\uB300\uD558\uB294 \uAC83\uC740 \uC815\uC2E0\uBCD1 \uCD08\uAE30\uC99D\uC138\uB2E4.");
		lblNewLabel_2.setBounds(12, 294, 403, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("- \uC544\uC778\uC288\uD0C0\uC778");
		lblNewLabel_3.setBounds(12, 318, 133, 25);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\uCC4C\uB9B0\uC9C0 \uC120\uD0DD!");
		lblNewLabel_4.setFont(new Font("HY����L", Font.BOLD, 20));
		lblNewLabel_4.setBounds(23, 22, 414, 50);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("\uB108...3\uC77C\uC740 \uB178\uB825\uD574\uBD24\uB2C8?");
		lblNewLabel_4_1.setFont(new Font("�ü�ü", Font.PLAIN, 18));
		lblNewLabel_4_1.setBounds(23, 82, 414, 50);
		panel.add(lblNewLabel_4_1);
		
		JButton btn_15Chal = new JButton("3\uB2E8\uACC4.\uC791\uC2EC\uBCF4\uB984.\uC624..");
		btn_15Chal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_15Chal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if( MyPage_Diary_copy.Challenge_num2 >= 7) {
				Challenge_2_2_3step.main(null);
				frame.dispose();
				}else {
					JOptionPane.showMessageDialog(null, "2�ܰ� �����ϰ� ������ ^^", "���� ���� �ȵ�!", JOptionPane.ERROR_MESSAGE);
				} 
			}
		});
		btn_15Chal.setBounds(237, 199, 200, 40);
		panel.add(btn_15Chal);
		
		JButton btn_30Chal = new JButton("4\uB2E8\uACC4.\uC791\uC2EC\uD55C\uB2EC!!!!");
		btn_30Chal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(MyPage_Diary_copy.Challenge_num3 >= 15) {
					Challenge_2_2_4step.main(null);
					frame.dispose();
				}else {
					JOptionPane.showMessageDialog(null, "3�ܰ� �����ϰ� ������ ^^", "���� ���� �ȵ�!", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btn_30Chal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_30Chal.setBounds(237, 249, 200, 40);
		panel.add(btn_30Chal);
		
		JButton btnNewButton = new JButton("\uB2EB\uAE30");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
			}
		});
		btnNewButton.setBounds(407, 309, 65, 42);
		panel.add(btnNewButton);
	}
}
