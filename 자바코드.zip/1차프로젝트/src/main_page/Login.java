package main_page;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;
import model.InsertVo;
import javax.swing.JPanel;
import java.awt.TextField;

public class Login {

	private JFrame frame;
	private JTextField txt_id;
	private TextField text_pw_;
	public static String cur_id;
	public static String cur_pw;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Login() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 245, 238));
		frame.setBounds(100, 100, 1078, 662);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		text_pw_ = new TextField();
		text_pw_.setFont(new Font("Dialog", Font.PLAIN, 16));
		text_pw_.setEchoCharacter('*');
		text_pw_.setBounds(557, 360, 247, 36);
		frame.getContentPane().add(text_pw_);

		txt_id = new JTextField();
		txt_id.setBounds(557, 283, 247, 36);
		frame.getContentPane().add(txt_id);
		txt_id.setColumns(10);

		JButton btn_login = new JButton("\uB85C\uADF8\uC778");

		btn_login.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				// txt_id,txt_pw�� �ִ� �ؽ�Ʈ�� ����������
				String id = txt_id.getText();
				String pw = text_pw_.getText();
				// 2.��輱 ���ֱ�

				// �� ������ InsertVO �����ֱ�
				DAO dao = new DAO();
				InsertVo vo = new InsertVo(id, pw);

				String name = dao.login(vo);
				if (name != null) {

					cur_id = id; // cur_id �� �α��� ���̵� �ٸ� ���̺��� ���� ������ ���
					cur_pw = pw;

					MyPage_Diary.main(null);
					frame.dispose();

				} else {
					JOptionPane.showMessageDialog(null, "�α��� ����", "�α��� ����â", JOptionPane.ERROR_MESSAGE);

				}

				// DAO ����

			}
		});
		btn_login.setBackground(new Color(255, 255, 255));
		btn_login.setForeground(new Color(0, 0, 0));
		btn_login.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_login.setBounds(557, 457, 152, 43);
		frame.getContentPane().add(btn_login);

		JButton btn_insert = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btn_insert.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				// textfield�� �ִ� ���� ������ �ͼ� ������ ����
				// id,pw,name,age ---> ���ڿ�
				// age ---> ������ ����!

				Insert_JoinMember.main(null);
				frame.dispose();
			}
		});
		btn_insert.setBackground(new Color(255, 255, 255));
		btn_insert.setForeground(new Color(0, 0, 0));
		btn_insert.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_insert.setBounds(342, 457, 152, 43);
		frame.getContentPane().add(btn_insert);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\smhrd\\Desktop\\asdasdasdasdazzz.jpg"));
		lblNewLabel.setBounds(0, 0, 1062, 623);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\loginpage.jpg"));
		lblNewLabel_1.setBounds(0, 0, 1062, 623);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
