package main_page;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import DAO.DAO;
import model.InsertCategory;
import model.InsertChallenge;
import model.InsertDiary;
import model.InsertVo;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class Challenge_input {

	private JFrame frame;
	private JTable table;
	private JTextField textField_37;
	private String chl = null;
	private String day = null;
	private String hob = null;
	private int time = 0;
	public String save = null;
	private ArrayList<InsertCategory> list = new ArrayList<InsertCategory>();
	public static int check;
	private DefaultTableModel model;
	private ArrayList<InsertCategory> returnList;
	DAO dao = new DAO();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Challenge_input window = new Challenge_input();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Challenge_input() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1078, 662);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(0, 0, 531, 623);
		frame.getContentPane().add(tabbedPane_1);

		JPanel panel = new JPanel();
		tabbedPane_1.addTab("ç���� ���", null, panel, null);
		panel.setLayout(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(12, 75, 483, 497);
		panel.add(panel_2);
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(3, 6, 23, 0));

		JLabel lblNewLabel_1 = new JLabel("\uC7A0\uC790\uB9AC \uC815\uB9AC");
		lblNewLabel_1.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(90, 27, 126, 18);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_1.setBackground(null);

		JLabel lblNewLabel_2 = new JLabel("\uC0AC\uB78C\uB4E4\uACFC \uC18C\uD1B5\uD558\uAE30");
		lblNewLabel_2.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(90, 55, 141, 18);
		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("\uBA85\uC0C1");
		lblNewLabel_3.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(90, 83, 84, 18);
		panel_2.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("\uCCB4\uC911 \uD655\uC778");
		lblNewLabel_4.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(90, 111, 105, 18);
		panel_2.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("\uC77C\uC815 \uD655\uC778");
		lblNewLabel_5.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(90, 139, 141, 18);
		panel_2.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("\uC2E0\uBB38 \uC77D\uAE30 ");
		lblNewLabel_6.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(90, 167, 134, 18);
		panel_2.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("\uC544\uCE68 \uACF5\uBD80 ");
		lblNewLabel_7.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(90, 195, 126, 18);
		panel_2.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("\uCF54\uB529\uC5F0\uC2B5\uD558\uAE30");
		lblNewLabel_8.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_8.setBounds(90, 223, 134, 18);
		panel_2.add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("\uBE44\uD0C0\uBBFC \uBA39\uAE30");
		lblNewLabel_9.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_9.setBounds(90, 251, 126, 18);
		panel_2.add(lblNewLabel_9);

		JLabel lblNewLabel_10 = new JLabel("\uC591\uCE58\uC9C8");
		lblNewLabel_10.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_10.setBounds(90, 279, 116, 18);
		panel_2.add(lblNewLabel_10);

		JLabel lblNewLabel_11 = new JLabel("\uC2A4\uD0A8\uCF00\uC5B4 ");
		lblNewLabel_11.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_11.setBounds(90, 307, 126, 18);
		panel_2.add(lblNewLabel_11);

		JLabel lblNewLabel_12 = new JLabel("\uC0E4\uC6CC ");
		lblNewLabel_12.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_12.setBounds(90, 335, 89, 18);
		panel_2.add(lblNewLabel_12);

		JLabel lblNewLabel_13 = new JLabel("\uD654\uC7A5\uD558\uAE30");
		lblNewLabel_13.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_13.setBounds(90, 363, 75, 18);
		panel_2.add(lblNewLabel_13);

		JLabel lblNewLabel_14 = new JLabel("\uBD09\uC0AC\uD558\uAE30");
		lblNewLabel_14.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_14.setBounds(90, 391, 98, 18);
		panel_2.add(lblNewLabel_14);

		JLabel lblNewLabel_15 = new JLabel("\uC637 \uAC08\uC544\uC785\uAE30");
		lblNewLabel_15.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_15.setBounds(90, 419, 134, 18);
		panel_2.add(lblNewLabel_15);

		JLabel lblNewLabel_16 = new JLabel("\uC804\uC790\uAE30\uAE30 \uC885\uB8CC");
		lblNewLabel_16.setBackground(SystemColor.menu);
		lblNewLabel_16.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_16.setBounds(296, 27, 135, 18);
		panel_2.add(lblNewLabel_16);

		JLabel lblNewLabel_17 = new JLabel("\uC544\uB450\uC774\uB178 \uC5F0\uC2B5");
		lblNewLabel_17.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_17.setBounds(296, 55, 187, 18);
		panel_2.add(lblNewLabel_17);

		JLabel lblNewLabel_18 = new JLabel("\uCEF4\uD4E8\uD130 \uBD84\uD574\uD558\uAE30");
		lblNewLabel_18.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_18.setBounds(296, 83, 187, 18);
		panel_2.add(lblNewLabel_18);

		JLabel lblNewLabel_19 = new JLabel("\uC2DD\uC0AC");
		lblNewLabel_19.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_19.setBounds(296, 111, 187, 18);
		panel_2.add(lblNewLabel_19);

		JLabel lblNewLabel_20 = new JLabel("\uCC28 \uB9C8\uC2DC\uAE30");
		lblNewLabel_20.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_20.setBounds(295, 139, 187, 18);
		panel_2.add(lblNewLabel_20);

		JLabel lblNewLabel_21 = new JLabel("\uC124\uAC70\uC9C0");
		lblNewLabel_21.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_21.setBounds(296, 167, 187, 18);
		panel_2.add(lblNewLabel_21);

		JLabel lblNewLabel_22 = new JLabel("\uBD84\uB9AC\uC218\uAC70");
		lblNewLabel_22.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_22.setBounds(296, 195, 187, 18);
		panel_2.add(lblNewLabel_22);

		JLabel lblNewLabel_23 = new JLabel("\uC77C\uC815 \uC815\uB9AC\uD558\uAE30");
		lblNewLabel_23.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_23.setBounds(296, 223, 187, 18);
		panel_2.add(lblNewLabel_23);

		JLabel lblNewLabel_24 = new JLabel("\uBB3C\uAC74\uC6D0\uC704\uCE58");
		lblNewLabel_24.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_24.setBounds(296, 251, 187, 18);
		panel_2.add(lblNewLabel_24);

		JLabel lblNewLabel_25 = new JLabel("\uACF5\uBD80");
		lblNewLabel_25.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_25.setBounds(296, 279, 187, 18);
		panel_2.add(lblNewLabel_25);

		JLabel lblNewLabel_26 = new JLabel("\uC77C\uAE30\uC4F0\uAE30");
		lblNewLabel_26.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_26.setBounds(296, 307, 187, 18);
		panel_2.add(lblNewLabel_26);

		JLabel lblNewLabel_27 = new JLabel("\uB0B4\uC77C \uC637 \uC900\uBE44");
		lblNewLabel_27.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_27.setBounds(296, 335, 187, 18);
		panel_2.add(lblNewLabel_27);

		JLabel lblNewLabel_28 = new JLabel("\uC6B4\uB3D9");
		lblNewLabel_28.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_28.setBounds(295, 363, 187, 18);
		panel_2.add(lblNewLabel_28);

		JLabel lblNewLabel_29 = new JLabel("\uB3C5\uC11C");
		lblNewLabel_29.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_29.setBounds(296, 391, 187, 18);
		panel_2.add(lblNewLabel_29);

		JLabel lblNewLabel_30 = new JLabel("\uC2A4\uD2B8\uB808\uCE6D");
		lblNewLabel_30.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_30.setBounds(296, 410, 187, 36);
		panel_2.add(lblNewLabel_30);

		ButtonGroup group1 = new ButtonGroup();

		JCheckBox ch1 = new JCheckBox("1");
		ch1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "���ڸ� ����";

			}
		});
		ch1.setForeground(Color.BLACK);
		ch1.setFont(new Font("����", Font.BOLD, 12));
		ch1.setBounds(46, 27, 36, 18);
		panel_2.add(ch1);
		ch1.setBackground(SystemColor.menu);

		JCheckBox ch2 = new JCheckBox("2");
		ch2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�� ���ñ�";
			}
		});
		ch2.setForeground(Color.BLACK);
		ch2.setFont(new Font("����", Font.BOLD, 12));
		ch2.setBounds(46, 54, 39, 18);
		panel_2.add(ch2);
		ch2.setBackground(SystemColor.menu);

		JCheckBox ch3 = new JCheckBox("3");
		ch3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "����";
			}
		});
		ch3.setForeground(Color.BLACK);
		ch3.setFont(new Font("����", Font.BOLD, 12));
		ch3.setBounds(46, 82, 36, 18);
		panel_2.add(ch3);
		ch3.setBackground(SystemColor.menu);

		JCheckBox ch4 = new JCheckBox("4");
		ch4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "ü�� Ȯ��";
			}
		});
		ch4.setForeground(Color.BLACK);
		ch4.setFont(new Font("����", Font.BOLD, 12));
		ch4.setBounds(46, 110, 39, 18);
		panel_2.add(ch4);
		ch4.setBackground(SystemColor.menu);

		JCheckBox ch5 = new JCheckBox("5");
		ch5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "���� Ȯ��";
			}
		});
		ch5.setForeground(Color.BLACK);
		ch5.setFont(new Font("����", Font.BOLD, 12));
		ch5.setBounds(46, 138, 36, 18);
		panel_2.add(ch5);
		ch5.setBackground(SystemColor.menu);

		JCheckBox ch6 = new JCheckBox("6");
		ch6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�Ź� �б�";
			}
		});
		ch6.setForeground(Color.BLACK);
		ch6.setFont(new Font("����", Font.BOLD, 12));
		ch6.setBounds(46, 166, 39, 18);
		panel_2.add(ch6);
		ch6.setBackground(SystemColor.menu);

		JCheckBox ch7 = new JCheckBox("7");
		ch7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "��ħ ����";
			}
		});
		ch7.setForeground(Color.BLACK);
		ch7.setFont(new Font("����", Font.BOLD, 12));
		ch7.setBounds(46, 194, 36, 18);
		panel_2.add(ch7);
		ch7.setBackground(SystemColor.menu);

		JCheckBox ch8 = new JCheckBox("8");
		ch8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "Ŀ��/ �� ���ñ�";
			}
		});
		ch8.setForeground(Color.BLACK);
		ch8.setFont(new Font("����", Font.BOLD, 12));
		ch8.setBounds(46, 222, 39, 18);
		panel_2.add(ch8);
		ch8.setBackground(SystemColor.menu);

		JCheckBox ch9 = new JCheckBox("9");
		ch9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "��/ ��Ÿ�� �Ա�";
			}
		});
		ch9.setForeground(Color.BLACK);
		ch9.setFont(new Font("����", Font.BOLD, 12));
		ch9.setBounds(47, 250, 36, 18);
		panel_2.add(ch9);
		ch9.setBackground(SystemColor.menu);

		JCheckBox ch10 = new JCheckBox("10");
		ch10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "��ġ��";
			}
		});
		ch10.setForeground(Color.BLACK);
		ch10.setFont(new Font("����", Font.BOLD, 12));
		ch10.setBounds(46, 278, 39, 18);
		panel_2.add(ch10);
		ch10.setBackground(SystemColor.menu);

		JCheckBox ch11 = new JCheckBox("11");
		ch11.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "��Ų�ɾ�";
			}
		});
		ch11.setForeground(Color.BLACK);
		ch11.setFont(new Font("����", Font.BOLD, 12));
		ch11.setBounds(46, 307, 41, 18);
		panel_2.add(ch11);
		ch11.setBackground(SystemColor.menu);

		JCheckBox ch12 = new JCheckBox("12");
		ch12.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "����";
			}
		});
		ch12.setForeground(Color.BLACK);
		ch12.setFont(new Font("����", Font.BOLD, 12));
		ch12.setBounds(46, 333, 39, 18);
		panel_2.add(ch12);
		ch12.setBackground(SystemColor.menu);

		JCheckBox ch13 = new JCheckBox("13");
		ch13.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "ȭ��";
			}
		});
		ch13.setForeground(Color.BLACK);
		ch13.setFont(new Font("����", Font.BOLD, 12));
		ch13.setBounds(46, 363, 41, 18);
		panel_2.add(ch13);
		ch13.setBackground(SystemColor.menu);

		JCheckBox ch14 = new JCheckBox("14");
		ch14.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "����";
			}
		});
		ch14.setForeground(Color.BLACK);
		ch14.setFont(new Font("����", Font.BOLD, 12));
		ch14.setBounds(46, 391, 39, 18);
		panel_2.add(ch14);
		ch14.setBackground(SystemColor.menu);

		JCheckBox ch15 = new JCheckBox("15");
		ch15.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�� �����Ա�";
			}
		});
		ch15.setForeground(Color.BLACK);
		ch15.setFont(new Font("����", Font.BOLD, 12));
		ch15.setBounds(46, 419, 41, 18);
		panel_2.add(ch15);
		ch15.setBackground(SystemColor.menu);

		JCheckBox ch16 = new JCheckBox("16");
		ch16.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "���ڱ�� ����";
			}
		});
		ch16.setForeground(Color.BLACK);
		ch16.setFont(new Font("����", Font.BOLD, 12));
		ch16.setBounds(249, 27, 49, 18);
		panel_2.add(ch16);
		ch16.setBackground(SystemColor.menu);

		JCheckBox ch17 = new JCheckBox("17");
		ch17.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "��ħ ����";
			}
		});
		ch17.setForeground(Color.BLACK);
		ch17.setFont(new Font("����", Font.BOLD, 12));
		ch17.setBounds(249, 55, 41, 18);
		panel_2.add(ch17);
		ch17.setBackground(SystemColor.menu);

		JCheckBox ch18 = new JCheckBox("18");
		ch18.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�Ļ� �غ�";
			}
		});
		ch18.setForeground(Color.BLACK);
		ch18.setFont(new Font("����", Font.BOLD, 12));
		ch18.setBounds(249, 83, 39, 18);
		panel_2.add(ch18);
		ch18.setBackground(SystemColor.menu);

		JCheckBox ch19 = new JCheckBox("19");
		ch19.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�Ļ�";
			}
		});
		ch19.setForeground(Color.BLACK);
		ch19.setFont(new Font("����", Font.BOLD, 12));
		ch19.setBounds(249, 111, 41, 18);
		panel_2.add(ch19);
		ch19.setBackground(SystemColor.menu);

		JCheckBox ch20 = new JCheckBox("20");
		ch20.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�� ���ñ�";
			}
		});
		ch20.setForeground(Color.BLACK);
		ch20.setFont(new Font("����", Font.BOLD, 12));
		ch20.setBounds(248, 139, 39, 18);
		panel_2.add(ch20);
		ch20.setBackground(SystemColor.menu);

		JCheckBox ch21 = new JCheckBox("21");
		ch21.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "������";
			}
		});
		ch21.setForeground(Color.BLACK);
		ch21.setFont(new Font("����", Font.BOLD, 12));
		ch21.setBounds(249, 167, 41, 18);
		panel_2.add(ch21);
		ch21.setBackground(SystemColor.menu);

		JCheckBox ch22 = new JCheckBox("22");
		ch22.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�и�����";
			}
		});
		ch22.setForeground(Color.BLACK);
		ch22.setFont(new Font("����", Font.BOLD, 12));
		ch22.setBounds(249, 195, 39, 18);
		panel_2.add(ch22);
		ch22.setBackground(SystemColor.menu);

		JCheckBox ch23 = new JCheckBox("23");
		ch23.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "���͸� ����";
			}
		});
		ch23.setForeground(Color.BLACK);
		ch23.setFont(new Font("����", Font.BOLD, 12));
		ch23.setBounds(249, 223, 41, 18);
		panel_2.add(ch23);
		ch23.setBackground(SystemColor.menu);

		JCheckBox ch24 = new JCheckBox("24");
		ch24.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "���� ���ڸ��� �α�";
			}
		});
		ch24.setForeground(Color.BLACK);
		ch24.setFont(new Font("����", Font.BOLD, 12));
		ch24.setBounds(249, 251, 39, 18);
		panel_2.add(ch24);
		ch24.setBackground(SystemColor.menu);

		JCheckBox ch25 = new JCheckBox("25");
		ch25.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "����";
			}
		});
		ch25.setForeground(Color.BLACK);
		ch25.setFont(new Font("����", Font.BOLD, 12));
		ch25.setBounds(249, 279, 41, 18);
		panel_2.add(ch25);
		ch25.setBackground(SystemColor.menu);

		JCheckBox ch26 = new JCheckBox("26");
		ch26.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "�ϱ� ����";
			}
		});
		ch26.setForeground(Color.BLACK);
		ch26.setFont(new Font("����", Font.BOLD, 12));
		ch26.setBounds(249, 307, 39, 18);
		panel_2.add(ch26);
		ch26.setBackground(SystemColor.menu);

		JCheckBox ch27 = new JCheckBox("27");
		ch27.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "���� �� �غ�";
			}
		});
		ch27.setForeground(Color.BLACK);
		ch27.setFont(new Font("����", Font.BOLD, 12));
		ch27.setBounds(249, 335, 41, 18);
		panel_2.add(ch27);
		ch27.setBackground(SystemColor.menu);

		JCheckBox ch28 = new JCheckBox("28");
		ch28.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "���� ���� Ȯ��";
			}
		});
		ch28.setForeground(Color.BLACK);
		ch28.setFont(new Font("����", Font.BOLD, 12));
		ch28.setBounds(249, 365, 39, 15);
		panel_2.add(ch28);
		ch28.setBackground(SystemColor.menu);

		JCheckBox ch29 = new JCheckBox("29");
		ch29.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "����";
			}
		});
		ch29.setForeground(Color.BLACK);
		ch29.setFont(new Font("����", Font.BOLD, 12));
		ch29.setBounds(249, 391, 41, 18);
		panel_2.add(ch29);
		ch29.setBackground(SystemColor.menu);

		JCheckBox ch30 = new JCheckBox("30");
		ch30.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hob = "��Ʈ��Ī";
			}
		});
		ch30.setForeground(Color.BLACK);
		ch30.setFont(new Font("����", Font.BOLD, 12));
		ch30.setBounds(249, 419, 39, 18);
		panel_2.add(ch30);
		ch30.setBackground(SystemColor.menu);

		group1.add(ch1);
		group1.add(ch2);
		group1.add(ch3);
		group1.add(ch4);
		group1.add(ch5);
		group1.add(ch6);
		group1.add(ch7);
		group1.add(ch8);
		group1.add(ch9);
		group1.add(ch10);
		group1.add(ch11);
		group1.add(ch12);
		group1.add(ch13);
		group1.add(ch14);
		group1.add(ch15);
		group1.add(ch16);
		group1.add(ch17);
		group1.add(ch18);
		group1.add(ch19);
		group1.add(ch20);
		group1.add(ch21);
		group1.add(ch22);
		group1.add(ch23);
		group1.add(ch24);
		group1.add(ch25);
		group1.add(ch26);
		group1.add(ch27);
		group1.add(ch28);
		group1.add(ch29);
		group1.add(ch30);

		textField_37 = new JTextField();
		textField_37.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent arg0) {

			}
		});
		textField_37.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_37.setBounds(369, 451, 56, 31);
		panel_2.add(textField_37);
		textField_37.setColumns(10);

		JLabel lblNewLabel_38 = new JLabel("\uBD84");
		lblNewLabel_38.setFont(new Font("HY������M", Font.BOLD, 15));
		lblNewLabel_38.setBounds(437, 456, 37, 26);
		panel_2.add(lblNewLabel_38);
		lblNewLabel_38.setBackground(new Color(3, 6, 23, 0));

		JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_2.setBackground(Color.WHITE);
		tabbedPane_2.setBounds(531, 0, 531, 623);
		frame.getContentPane().add(tabbedPane_2);

		JPanel panel_1 = new JPanel();
		tabbedPane_2.addTab("��� ��Ȳ", null, panel_1, null);
		panel_1.setLayout(null);

		JButton btn_delete_com = new JButton("\uC0AD\uC81C\uC644\uB8CC");
		btn_delete_com.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_delete_com.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				returnList = new ArrayList<InsertCategory>();

				for (int i = 0; i < model.getRowCount(); i++) {

					String routine = (String) model.getValueAt(i, 0);
					String habit = (String) model.getValueAt(i, 1);
					int habit_time = (int) model.getValueAt(i, 2);

					InsertCategory chal_fix = new InsertCategory(routine, habit, habit_time);
					returnList.add(chal_fix);
				}

				dao.Chal_InsertUpdate(returnList);

			}
		});
		btn_delete_com.setForeground(Color.WHITE);
		btn_delete_com.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_delete_com.setBackground(SystemColor.activeCaption);
		btn_delete_com.setBounds(180, 532, 147, 51);
		panel_1.add(btn_delete_com);

		JScrollPane scrollPane_Print = new JScrollPane();
		scrollPane_Print.setBounds(12, 10, 502, 435);
		panel_1.add(scrollPane_Print);
		scrollPane_Print.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane_Print.setBackground(Color.WHITE);
		JViewport viewport = new JViewport();
		viewport.setOpaque(false);
		scrollPane_Print.setViewport(viewport);

		ButtonGroup group = new ButtonGroup();

		JRadioButton rdbtnNewRadioButton = new JRadioButton("\uC544\uCE68");
		rdbtnNewRadioButton.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnNewRadioButton.setBackground(SystemColor.menu);
		rdbtnNewRadioButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				day = "��ħ";

			}
		});

		rdbtnNewRadioButton.setFont(new Font("���ʷҵ���", Font.BOLD, 15));
		rdbtnNewRadioButton.setBounds(46, 21, 98, 48);
		panel.add(rdbtnNewRadioButton);
		String text = rdbtnNewRadioButton.getText();

		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\uC810\uC2EC");
		rdbtnNewRadioButton_1.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnNewRadioButton_1.setBackground(SystemColor.menu);
		rdbtnNewRadioButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				day = "����";

			}
		});

		rdbtnNewRadioButton_1.setFont(new Font("���ʷҵ���", Font.BOLD, 15));
		rdbtnNewRadioButton_1.setBounds(213, 21, 81, 48);
		panel.add(rdbtnNewRadioButton_1);

		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("\uC800\uB141");
		rdbtnNewRadioButton_2.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnNewRadioButton_2.setBackground(SystemColor.menu);
		rdbtnNewRadioButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				day = "����";

			}
		});
		rdbtnNewRadioButton_2.setFont(new Font("���ʷҵ���", Font.BOLD, 15));
		rdbtnNewRadioButton_2.setBounds(359, 21, 98, 48);
		panel.add(rdbtnNewRadioButton_2);

		group.add(rdbtnNewRadioButton);
		group.add(rdbtnNewRadioButton_1);
		group.add(rdbtnNewRadioButton_2);

		JButton btn_close = new JButton("\uB2EB\uAE30");
		btn_close.setForeground(Color.WHITE);
		btn_close.setBackground(SystemColor.activeCaption);
		btn_close.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_close.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
			}
		});
		btn_close.setBounds(361, 532, 153, 51);
		panel_1.add(btn_close);

		table = new JTable();
		scrollPane_Print.setViewportView(table);

		JButton btn_save1 = new JButton("\uB4F1\uB85D\uD558\uAE30");
		btn_save1.setForeground(Color.WHITE);
		btn_save1.setBackground(SystemColor.activeCaption);
		btn_save1.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_save1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				time = Integer.parseInt(textField_37.getText());
				DAO dao = new DAO();
				// day,hob,time ---> db�� �־��ְ� �� ������

				// ArrayList<InsertVo> list = dao.allSelect();

				list.add(new InsertCategory(day, hob, time));

				String[] column = { "�ð�", "�� ��", "��" };
				Object[][] data = new Object[list.size()][column.length];
				for (int i = 0; i < list.size(); i++) {
					data[i][0] = list.get(i).getRoutine();
					data[i][1] = list.get(i).getHabit();
					data[i][2] = list.get(i).getHabit_time();

				}
				table.setModel(new DefaultTableModel(data, column));
			}
		});
		btn_save1.setBounds(361, 455, 153, 51);
		panel_1.add(btn_save1);

		JButton btn_save2 = new JButton("\uC800\uC7A5\uD558\uAE30");
		btn_save2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_save2.setForeground(Color.WHITE);
		btn_save2.setBackground(SystemColor.activeCaption);
		btn_save2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DAO dao = new DAO();
				String[] column = { "�ð�", "�� ��", "��" };
				Object[][] data = new Object[list.size()][column.length];

				for (int i = 0; i < list.size(); i++) {
					data[i][0] = list.get(i).getRoutine();
					data[i][1] = list.get(i).getHabit();
					data[i][2] = list.get(i).getHabit_time();
					check = 1;
				}
				int result = dao.insert1(list);
				if (result > 0) {
					JOptionPane.showMessageDialog(null, "���� ����!", "����â", JOptionPane.INFORMATION_MESSAGE);
				}
				table.setModel(new DefaultTableModel(data, column));
			}
		});
		btn_save2.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_save2.setBounds(12, 531, 135, 53);
		panel_1.add(btn_save2);

		JLabel lblNewLabel_39 = new JLabel("");
		lblNewLabel_39.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\\uC0AC\uC9C4\\r.PNG"));
		lblNewLabel_39.setBounds(0, 0, 526, 594);
		panel_1.add(lblNewLabel_39);

		JButton btn_selectall = new JButton("\uC804\uCCB4\uBCF4\uAE30");
		btn_selectall.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				//// ��ü �Է�
				dao = new DAO();

				list = dao.Chal_allSelect_category(Login.cur_id);
//			ArrayList<InsertDiary> list = dao.allSelect_diary(Login.cur_id);

				if (list.size() != 0) {

					String[] column = { "�ð�", "�� ��", "��" };
					Object[][] data = new Object[list.size()][column.length];

					for (int i = 0; i < list.size(); i++) {
						data[i][0] = list.get(i).getRoutine();
						data[i][1] = list.get(i).getHabit();
						data[i][2] = list.get(i).getHabit_time();
					}
					model = new DefaultTableModel(data, column);
					table.setModel(model);
				} else {
					JOptionPane.showMessageDialog(null, "���� ������ �����ϴ�.", "������ �Է����ּ���", JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		btn_selectall.setForeground(Color.WHITE);
		btn_selectall.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_selectall.setBackground(SystemColor.activeCaption);
		btn_selectall.setBounds(12, 455, 135, 53);
		panel_1.add(btn_selectall);

		JButton btn_delete = new JButton("\uC0AD\uC81C\uD558\uAE30");
		btn_delete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				int index = table.getSelectedRow();
				model.removeRow(index);
				table.setModel(model);

			}
		});
		btn_delete.setForeground(Color.WHITE);
		btn_delete.setFont(new Font("���ʷҵ���", Font.BOLD, 25));
		btn_delete.setBackground(SystemColor.activeCaption);
		btn_delete.setBounds(180, 455, 147, 53);
		panel_1.add(btn_delete);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(SystemColor.menu);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\\uC0AC\uC9C4\\l.PNG"));
		lblNewLabel.setBounds(0, 0, 526, 594);
		panel.add(lblNewLabel);

	}
}