package model;

public class InsertCategory {
	
	
	private String routine, habit, achieve;
	private int habit_time, chal_id, chal;
	private String check;
	



	public InsertCategory(String achieve, int chal, String check) {
		this.achieve = achieve;
		this.chal = chal;
		this.check = check;
	}



	public String getCheck() {
		return check;
	}



	public void setCheck(String check) {
		this.check = check;
	}



	public InsertCategory(String achieve, int chal) {
		this.achieve = achieve;
		this.chal = chal;
	}



	public InsertCategory(String routine, String habit, int habit_time) {
		this.routine = routine;
		this.habit = habit;
		this.habit_time = habit_time;
	}
	
	
	
	public InsertCategory(String routine, String habit, int habit_time, String achieve,int chal) {
		this.routine = routine;
		this.habit = habit;
		this.achieve = achieve;
		this.habit_time = habit_time;
		this.chal = chal;
	}
	public InsertCategory(int chal) {
		this.chal = chal;
	}
	public String getRoutine() {
		return routine;
	}
	public void setRoutine(String routine) {
		this.routine = routine;
	}
	public String getHabit() {
		return habit;
	}
	public void setHabit(String habit) {
		this.habit = habit;
	}
	public String getAchieve() {
		return achieve;
	}
	public void setAchieve(String achieve) {
		this.achieve = achieve;
	}
	public int getHabit_time() {
		return habit_time;
	}
	public void setHabit_time(int habit_time) {
		this.habit_time = habit_time;
	}
	public int getChal_id() {
		return chal_id;
	}
	public void setChal_id(int chal_id) {
		this.chal_id = chal_id;
	}
	public int getChal() {
		return chal;
	}
	public void setChal(int chal) {
		this.chal = chal;
	}

}
