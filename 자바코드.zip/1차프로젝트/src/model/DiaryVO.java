package model;

import java.util.Date;

public class DiaryVO {
	
	String event;
	String habit;
	Date start;
	Date complete;
	String achieve;
	
	public DiaryVO(String event, String habit, Date start, Date complete, String achieve) {
		this.event = event;
		this.habit = habit;
		this.start = start;
		this.complete = complete;
		this.achieve = achieve;
	}
	public String getAchieve() {
		return achieve;
	}
	public void setAchieve(String achieve) {
		this.achieve = achieve;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getHabit() {
		return habit;
	}
	public void setHabit(String habit) {
		this.habit = habit;
	}
	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	public Date getComplete() {
		return complete;
	}
	public void setComplete(Date complete) {
		this.complete = complete;
	}
	
	

}
