package main_page;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import DAO.DAO;
import GUI_.MyDefaultTableCellRenderer;
import model.InsertCategory;
import model.InsertChallenge;
import model.InsertDiary;
import model.InsertVo;
import model.wise;

import javax.swing.JScrollPane;
import java.awt.FlowLayout;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JCalendar;

public class MyPage_Diary_copy {

	private JFrame frame;
	private JTable table;
	private JTable table_1;
	DAO dao = new DAO();
	Login login = new Login();
	ArrayList<InsertCategory> list;
	Object[][] data1;
	protected static final TableCellRenderer dtcr1 = null;
	public static int Challenge_num;
	public static int Challenge_num2;
	public static int Challenge_num3;
	public static int Challenge_num4;
	private JLabel lbl_hi_;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyPage_Diary_copy window = new MyPage_Diary_copy();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MyPage_Diary_copy() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1078, 662);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JTabbedPane tabPan_mypage_1 = new JTabbedPane(JTabbedPane.TOP);
		tabPan_mypage_1.setBounds(0, 0, 531, 623);
		frame.getContentPane().add(tabPan_mypage_1);

		JPanel pan_myHobby = new JPanel();
		tabPan_mypage_1.addTab("���� ����", null, pan_myHobby, null);
		pan_myHobby.setLayout(null);
		// �̸� + �ȳ��ϼ��� ���� �ڿ� ���� ��� ������ �� ����.
		String id = login.cur_id;
		String pw = login.cur_pw;
		InsertVo vo = new InsertVo(id, pw);
		String name = dao.login(vo);
		String name2 = null;
		if(name!=null) {
			name2 = name;
		}
		
		lbl_hi_ = new JLabel(name2 + "�� �ȳ��ϼ���.");
		lbl_hi_.setBounds(12, 9, 502, 101);
		pan_myHobby.add(lbl_hi_);
		lbl_hi_.setFont(new Font("�޸ո���ü", Font.PLAIN, 22));
		
		JScrollPane scrollPane_Print = new JScrollPane();
		scrollPane_Print.setBounds(12, 120, 502, 370);
		pan_myHobby.add(scrollPane_Print);

		table = new JTable();
		scrollPane_Print.setViewportView(table);

		JButton btn_print = new JButton("\uD604\uC7AC \uC0C1\uD669");
		btn_print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_print.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				dao = new DAO();
				ArrayList<InsertDiary> list = dao.Select_Goal(Login.cur_id);

				if (list.size() != 0) {
					System.out.println(list.get(0).getTitle());

					// System.out.println(list.get(0).getTitle());
					String[] column = { "�з�", "��ǥ ����", "���� ��¥", "�Ϸ� ��¥", "�޼�����" };
					// event, goal , start_date, final date
					Object[][] data = new Object[list.size()][column.length];

					System.out.println(list.get(0).getEvent());

//				data[0][0] = list.get(0).getEvent();
//				data[0][1] = list.get(0).getGoal();
//				data[0][2] = list.get(0).getStart_date();
//				data[0][3] = list.get(0).getFinal_date();
//				data[0][4] = null;
					System.out.println(list.get(0).getAchieve());
					for (int i = 0; i < list.size(); i++) {
						data[i][0] = list.get(i).getEvent();
						data[i][1] = list.get(i).getGoal();
						data[i][2] = list.get(i).getStart_date();
						data[i][3] = list.get(i).getFinal_date();
						data[i][4] = list.get(i).getAchieve();
					}
					table.setModel(new DefaultTableModel(data, column));
				} else {
					JOptionPane.showMessageDialog(null, "���� ������ �����ϴ�.", "������ �Է����ּ���", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		System.out.println(Login.cur_id);

		btn_print.setFont(new Font("���ʷҵ���", Font.BOLD, 20));
		btn_print.setBackground(Color.LIGHT_GRAY);
		btn_print.setBounds(352, 500, 162, 84);
		pan_myHobby.add(btn_print);

		wise wi = new wise();

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(
				new ImageIcon("C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\\uC0AC\uC9C4\\page.jpg"));
		lblNewLabel_3.setBounds(0, 0, 526, 594);
		pan_myHobby.add(lblNewLabel_3);

		//
		JPanel pan_makeHobby = new JPanel();
		tabPan_mypage_1.addTab("���� �����", null, pan_makeHobby, null);
		pan_makeHobby.setLayout(null);

		JButton btnNewButton = new JButton("\uBAA9\uD45C \uC815\uD558\uAE30");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Make_Habit.main(null);
			}
		});
		
		JLabel lbl_achieve_score = new JLabel("���� �� ���� �޼��� : "+Make_Habit.total);
		lbl_achieve_score.setFont(new Font("����", Font.PLAIN, 16));
		lbl_achieve_score.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_achieve_score.setBounds(127, 395, 259, 90);
		pan_makeHobby.add(lbl_achieve_score);
		btnNewButton.setBounds(184, 306, 136, 76);
		pan_makeHobby.add(btnNewButton);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(
				new ImageIcon("C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\\uC0AC\uC9C4\\goal.jpg"));
		lblNewLabel_1.setBounds(0, 0, 526, 594);
		pan_makeHobby.add(lblNewLabel_1);

		JPanel pan_challenge = new JPanel();
		tabPan_mypage_1.addTab("���� �۽ɻ���", null, pan_challenge, null);
		pan_challenge.setLayout(null);

		JButton btn_challenge = new JButton("\uB3C4\uC804");
		btn_challenge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_challenge.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				Challenge_input.main(null);

			}
		});

		JButton btn_1 = new JButton("\uB3C4\uC804\uC870\uD68C");
		btn_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_1.setFont(new Font("���ʷҵ���", Font.BOLD, 20));
		btn_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				DAO dao = new DAO();
				list = dao.selectCategory(Login.cur_id);

				String[] column1 = { "�ð�", "�� ��", "��" };

				data1 = new Object[list.size()][column1.length];

				for (int i = 0; i < list.size(); i++) {
					data1[i][0] = list.get(i).getRoutine();
					data1[i][1] = list.get(i).getHabit();
					data1[i][2] = list.get(i).getHabit_time();
					// data1[i][3] = "";
				}
				table_1.setModel(new DefaultTableModel(data1, column1));
//			            table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//			            JCheckBox CheckBox = new JCheckBox();
//			            table_1.getColumn("�޼� ����").setCellRenderer(dtcr1);
//			            table_1.getColumn("�޼� ����").setCellEditor(new DefaultCellEditor(CheckBox));
//			            DefaultTableCellRenderer render = new MyDefaultTableCellRenderer();
//			            System.out.println(table_1.getColumn("�޼� ����"));
//			            table_1.getColumn("�޼� ����").setCellRenderer(render);

			}
		});

		JButton btn_challenge_start = new JButton("\uB3C4\uC804\uC2DC\uC791");
		btn_challenge_start.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				///
				int check1 = Challenge_input.check;
				if (check1 == 1) {
					Challenge_choice.main(null);
				} else {
					JOptionPane.showMessageDialog(null, "���� ��� ����� �;���!", "���� ���� �ȵ�!", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btn_challenge_start.setFont(new Font("���ʷҵ���", Font.BOLD, 20));
		btn_challenge_start.setBounds(318, 486, 176, 98);
		pan_challenge.add(btn_challenge_start);
		btn_1.setBounds(138, 486, 130, 98);
		pan_challenge.add(btn_1);
		btn_challenge.setFont(new Font("���ʷҵ���", Font.BOLD, 20));
		btn_challenge.setBounds(12, 486, 114, 98);
		pan_challenge.add(btn_challenge);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 66, 482, 410);
		pan_challenge.add(scrollPane_1);

		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setFont(new Font("HY����L", Font.BOLD, 25));
		lblNewLabel_4.setIcon(new ImageIcon(
				"C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\\uC0AC\uC9C4\\challenge.jpg"));
		lblNewLabel_4.setBounds(0, 0, 526, 594);
		pan_challenge.add(lblNewLabel_4);

		table_1 = new JTable();
		table_1.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		scrollPane_1.setViewportView(table_1);

		JPanel pan_myInfo = new JPanel();
		tabPan_mypage_1.addTab("My Info", null, pan_myInfo, null);
		pan_myInfo.setLayout(null);

		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\\uC0AC\uC9C4\\uCC98vvvvvvvvvvvvvvv.png"));
		lblNewLabel_6.setBounds(0, 0, 526, 594);
		pan_myInfo.add(lblNewLabel_6);

		JTabbedPane tabPan_mypage_2 = new JTabbedPane(JTabbedPane.TOP);
		tabPan_mypage_2.setBounds(531, 0, 531, 623);
		frame.getContentPane().add(tabPan_mypage_2);

		JPanel pan_calendar = new JPanel();
		tabPan_mypage_2.addTab("�����", null, pan_calendar, null);
		pan_calendar.setLayout(null);
				
				JButton btnNewButton_1 = new JButton("\uC0C8\uB85C\uACE0\uCE68");
				btnNewButton_1.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						frame.dispose();
						MyPage_Diary_copy.main(null);
					}
				});
				btnNewButton_1.setBounds(12, 539, 97, 45);
				pan_calendar.add(btnNewButton_1);
				
//				JLabel lbl_30_1 = new JLabel(": "+Challenge_num4);
				JLabel lbl_30_1 = new JLabel(": "+1+"ȸ ����");
				lbl_30_1.setFont(new Font("����", Font.BOLD, 15));
				lbl_30_1.setBounds(12, 427, 212, 45);
				pan_calendar.add(lbl_30_1);
				
				JLabel lbl_15_1 = new JLabel(": "+1+"ȸ ����");
//				JLabel lbl_15_1 = new JLabel(": "+Challenge_num3);
				lbl_15_1.setFont(new Font("����", Font.BOLD, 15));
				lbl_15_1.setBounds(12, 325, 212, 45);
				pan_calendar.add(lbl_15_1);
				
				JLabel lbl_7_1 = new JLabel(": "+2+"ȸ ����");
//				JLabel lbl_7_1 = new JLabel(": "+Challenge_num2);
				lbl_7_1.setFont(new Font("����", Font.BOLD, 15));
				lbl_7_1.setBounds(12, 230, 212, 45);
				pan_calendar.add(lbl_7_1);
				
//				JLabel lbl_3_1 = new JLabel(": "+Challenge_num);
				JLabel lbl_3_1 = new JLabel(": "+5+"ȸ ����");
				lbl_3_1.setFont(new Font("����", Font.BOLD, 15));
				lbl_3_1.setBounds(12, 156, 212, 45);
				pan_calendar.add(lbl_3_1);
				
				JLabel lbl_30 = new JLabel("\uD55C\uB2EC \uCC4C\uB9B0\uC9C0 \uC131\uACF5\uC5EC\uBD80");
				lbl_30.setFont(new Font("����", Font.BOLD, 15));
				lbl_30.setBounds(12, 401, 212, 45);
				pan_calendar.add(lbl_30);
				
				JLabel lbl_15 = new JLabel("\uBCF4\uB984 \uCC4C\uB9B0\uC9C0 \uC131\uACF5\uC5EC\uBD80");
				lbl_15.setFont(new Font("����", Font.BOLD, 15));
				lbl_15.setBounds(12, 299, 212, 45);
				pan_calendar.add(lbl_15);
				
				JLabel lbl_7 = new JLabel("\uC77C\uC8FC\uC77C \uCC4C\uB9B0\uC9C0 \uC131\uACF5\uC5EC\uBD80");
				lbl_7.setFont(new Font("����", Font.BOLD, 15));
				lbl_7.setBounds(12, 204, 212, 45);
				pan_calendar.add(lbl_7);
				
				JLabel lbl_3 = new JLabel("3\uC77C \uCC4C\uB9B0\uC9C0 \uC131\uACF5\uC5EC\uBD80");
				lbl_3.setFont(new Font("����", Font.BOLD, 15));
				lbl_3.setBounds(12, 120, 212, 45);
				pan_calendar.add(lbl_3);
		
				JLabel lblNewLabel_2 = new JLabel(wi.wise1());
				lblNewLabel_2.setBounds(12, 10, 476, 100);
				pan_calendar.add(lblNewLabel_2);
				lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);

		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon(
				"C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\\uC0AC\uC9C4\\mainpage.jpg"));
		lblNewLabel_5.setBounds(0, 0, 526, 594);
		pan_calendar.add(lblNewLabel_5);

	
		

		JPanel panel_space = new JPanel();
		tabPan_mypage_2.addTab("�޷�", null, panel_space, null);
		panel_space.setLayout(null);
		
		JCalendar calendar = new JCalendar();
		calendar.setBounds(0, 0, 526, 594);
		panel_space.add(calendar);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\1\uCC28 \uD504\uB85C\uC81D\uD2B8\\\uC0AC\uC9C4\\mainpage.jpg"));
		lblNewLabel.setBounds(0, 0, 526, 594);
		panel_space.add(lblNewLabel);

		JLabel lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setBounds(0, 0, 526, 594);
		lblNewLabel_9.setIcon(new ImageIcon("C:\\Users\\SMHRD\\Desktop\\\uC0AC\uC9C4\\uCC98b.png"));
		panel_space.add(lblNewLabel_9);
	}
}