package model;

import java.util.Date;

public class InsertDiary {
	
	
	private String user_id, event, title, goal, achieve;
	private int event_id;
	
	
	public InsertDiary(String achieve, int event_id) {
		this.achieve = achieve;
		this.event_id = event_id;
	}


	public InsertDiary(String event, String goal, Date start_date, Date final_date, String achieve, int event_id) {
		this.event = event;
		this.goal = goal;
		this.achieve = achieve;
		this.event_id = event_id;
		this.start_date = start_date;
		this.final_date = final_date;
	}


	private Date start_date,final_date;
	
	
//	public InsertDiary(String goal, int event_id, Date start_date, Date final_date) {
//		this.goal = goal;
//		this.event_id = event_id;
//		this.start_date = start_date;
//		this.final_date = final_date;
//	}

	

	public InsertDiary(String event, String goal, Date start_date, Date final_date, String achieve) {
		this.event = event;
		this.goal = goal;
		this.start_date = start_date;
		this.final_date = final_date;
		this.achieve = achieve;
	}


	public InsertDiary(String event, String goal, String achieve, Date start_date, Date final_date) {
	super();
	this.event = event;
	this.goal = goal;
	this.achieve = achieve;
	this.start_date = start_date;
	this.final_date = final_date;
}


	public InsertDiary(String event, String goal, Date start_date, Date final_date) {
		this.event = event;
		this.goal = goal;
		this.start_date = start_date;
		this.final_date = final_date;
	}


	public InsertDiary() {
	}




	public String getUser_id() {
		return user_id;
	}


	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}


	public String getEvent() {
		return event;
	}


	public void setEvent(String event) {
		this.event = event;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getGoal() {
		return goal;
	}


	public void setGoal(String goal) {
		this.goal = goal;
	}


	public String getAchieve() {
		return achieve;
	}


	public void setAchieve(String achieve) {
		this.achieve = achieve;
	}


	public int getEvent_id() {
		return event_id;
	}


	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}


	public Date getStart_date() {
		return start_date;
	}


	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}


	public Date getFinal_date() {
		return final_date;
	}


	public void setFinal_date(Date final_date) {
		this.final_date = final_date;
	}
	
	
	
	
	
	
	
	

}
